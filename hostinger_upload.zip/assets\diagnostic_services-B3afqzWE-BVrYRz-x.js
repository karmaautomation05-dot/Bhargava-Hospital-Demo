const s="/assets/modular_ot-DoB3xoZp.png",o="/assets/icu_nicu-ES2TG7dj.png",t="/assets/diagnostic_services-SpXX28j0.png";export{o,s,t};
